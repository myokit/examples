Myokit DataBlock2d Binary File
==============================
This zip file contains simulation data in the form of multiple time series.
Zero-dimensional time series, such as time or a global pace variable are
stored, as well as two-dimensional time series, such as the membrane potential
of a 2d grid of cells, as it varies over time.

This file has the following entries:

header_block2d.txt
------------------
A header file containing the following information (line by line):

  - nt     the number of points in time in each entry
  - ny     the height of each 2d block
  - nx     the width of each 2d block
  - dtype  the used datatype (either "d" or "f")
  - name   the names of all 0d entries, each on its own line
  - 2      the indication that the 2d entries are starting
  - name   the names of all 2d entries, each on its own line

data.bin
--------
A binary file containing the following data, in the data type specified by the
header, and little-endian:

  - The nt time values
  - All 0d entries
  - All 2d entries, reshaped using numpy order='C'